# KuserManager
~~~
Version 0.0.1
licenced under the GPL3
Use at your own risk
Simple kdilaog that allows you to display
and modify your systems Users and Groups
~~~
